# MoneyEdXpat Website

Personal website of Darema Dzhold — Expat Financial Adviser in Shanghai, China.

## How to update

- Edit the `.html` files directly in GitHub
- Replace `[WeChat QR Code]` placeholder with your actual QR code image
- Update the Formspree ID in `contact.html` (sign up free at formspree.io)

## Setup

1. Go to your repository Settings → Pages
2. Set Source to `main` branch, root folder
3. Your site will be live at `https://darema21.github.io/moneyedexpat`

To connect your custom domain, add a file called `CNAME` containing just: `moneyedxpat.com`
